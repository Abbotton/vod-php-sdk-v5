<?php

namespace Guzzle\Tests\Service\Mock\Command\Sub;

use Guzzle\Tests\Service\Mock\Command\MockCommand;

class Sub extends MockCommand {}
